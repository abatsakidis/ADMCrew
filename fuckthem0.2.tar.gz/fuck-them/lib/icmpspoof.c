
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netdb.h>
#include <netinet/in.h>

#include "../include/ip.h"
#include "../include/icmp.h"

#define IPHDRSIZE     sizeof(struct iphdr  )
#define ICMPHDRSIZE   sizeof(struct icmphdr)
#define TCPHDRSIZE    sizeof(struct tcphdr )
#define PSEUDOHDRSIZE sizeof(struct pseudohdr)
#define UDPHDRSIZE    sizeof(struct udphdr)
#define ERROR -1

/*****************************************************************************/
/* structure of the pseudo header                                            */
/*****************************************************************************/
struct pseudohdr
  {
    unsigned long saddr;
    unsigned long daddr;
    char useless;
    unsigned char protocol;
    unsigned short leng;
  };



/*****************************************************************************/
/*
 * in_cksum --
 *  Checksum routine for Internet Protocol family headers (C Version)
 */
/*****************************************************************************/

unsigned short 
in_cksum (addr, len)
     u_short *addr;
     int len;
{
  register int nleft = len;
  register u_short *w = addr;
  register int sum = 0;
  u_short answer = 0;

  /*
   * Our algorithm is simple, using a 32 bit accumulator (sum), we add
   * sequential 16 bit words to it, and at the end, fold back all the
   * carry bits from the top 16 bits into the lower 16 bits.
   */
  while (nleft > 1)
    {
      sum += *w++;
      nleft -= 2;
    }

  /* mop up an odd byte, if necessary */
  if (nleft == 1)
    {
      *(u_char *) (&answer) = *(u_char *) w;
      sum += answer;
    }

  /* add back carry outs from top 16 bits to low 16 bits */
  sum = (sum >> 16) + (sum & 0xffff);	/* add hi 16 to low 16 */
  sum += (sum >> 16);		/* add carry */
  answer = ~sum;		/* truncate to 16 bits */
  return (answer);
}

/****************************************************************************/
/*                     SEND A ICMP PACKET                                   */
/*    hehe ripped from ADMscan2 :)                                          */
/****************************************************************************/

  int icmp_echo(int s,unsigned long int src, unsigned long int dest,int id,int seq,
  unsigned char* data, unsigned short datasize) 
   {
   struct iphdr   *ip;
   struct icmphdr *icmp;
   unsigned char *icmpdata;
   unsigned char *packet;
   struct sockaddr_in sin_dst;
   int n;

   packet = (unsigned char*)malloc(IPHDRSIZE +ICMPHDRSIZE+datasize+1);

   if (packet == NULL) {
   puts("malloc error");
   return( -1);
   }

   ip = (struct iphdr *)packet;
   icmp = (struct icmphdr *)(packet+IPHDRSIZE);
   icmpdata = (unsigned char *)(packet+IPHDRSIZE+ICMPHDRSIZE);

   ip->saddr    = src;
   ip->daddr    = dest;
   ip->version  = 4;
   ip->ihl      = 5;
   ip->ttl      = 255;
   ip->protocol = 1;
   ip->tot_len  = htons(IPHDRSIZE +ICMPHDRSIZE+datasize);
   ip->tos      = 0;
   ip->id       = 0;
   ip->off = 0;
   ip->check    = 0;
   ip->check    = in_cksum(ip,IPHDRSIZE);

   icmp->type   = 8;
   icmp->code   = 0;
   icmp->checksum = 0;
   icmp->id  = id;
   icmp->sequence = seq;
   memcpy(icmpdata,data,datasize);
   icmp->checksum = in_cksum(icmp,ICMPHDRSIZE+datasize);

   sin_dst.sin_addr.s_addr = ip->daddr;
   sin_dst.sin_family = AF_INET;

   n=sendto(s,packet,IPHDRSIZE+ICMPHDRSIZE+datasize,0,
   (struct sockaddr*)&sin_dst,sizeof(struct sockaddr));
   if (n==-1) puts("sendto error");
   free(packet);
  return ( 0 );
   }

