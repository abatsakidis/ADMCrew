
struct icmphdr {
  unsigned char	type;
  unsigned char		code;
  unsigned short	checksum;
  unsigned short	id;
  unsigned short	sequence;
};


