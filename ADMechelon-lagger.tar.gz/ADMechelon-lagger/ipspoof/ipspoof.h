

#ifndef _IPSPOOF_H
#define _IPSPOOF_H

#include <netinet/in.h>

#include "ip.h"
#include "tcp.h"


#define PSEUDOHDRSIZE sizeof(struct pseudohdr)
#define UDPHDRSIZE    sizeof(struct udphdr)
#define GGPHDRSIZE    sizeof(struct ggphdr)

#define ICMPHDRSIZE sizeof(struct icmphdr)
#define IPHDRSIZE  sizeof(struct iphdr)
#define TCPHDRSIZE sizeof(struct tcphdr)
#define UDPHDRSIZE sizeof(struct udphdr)
#define ERROR -1

#endif _IPSPOOF_H
