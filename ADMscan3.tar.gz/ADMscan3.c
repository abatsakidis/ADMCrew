#define IPHDRSIZE sizeof(struct iphdr)
#define ICMPHDRSIZE sizeof(struct icmphdr)
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/ioctl.h>
//#include <sys/filio.h>
#include <sys/types.h>
#include <sys/socket.h>
//#include "mytypes.h"
#include "ip.h"
#include "ip_icmp.h"
#include <netinet/in.h>
#include <netdb.h>
extern char *inet_ntoa(struct in_addr);
extern int atoi(const char *);
extern char *strncpy(char *, const char *, size_t );
extern void *memset(void *, int , size_t );

int raw_send,raw_icmp;
unsigned char packet[IPHDRSIZE +ICMPHDRSIZE+1] =  //datasize is always 0
"\x45\x00"
"\x00\x1c" //htons(IPHDRSIZE +ICMPHDRSIZE)
"\x00\x00\x00\x00\xff\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00" //end of IP
"\x08\x00";


/*
 * in_cksum --
 *  Checksum routine for Internet Protocol family headers (C Version)
 */
unsigned short in_cksum(addr, len)
    u_short *addr;
    int len;
{
    register int nleft = len;
    register u_short *w = addr;
    register int sum = 0;
    u_short answer = 0;
 
    /*
     * Our algorithm is simple, using a 32 bit accumulator (sum), we add
     * sequential 16 bit words to it, and at the end, fold back all the
     * carry bits from the top 16 bits into the lower 16 bits.
     */
    while (nleft > 1)  {
        sum += *w++;
        nleft -= 2;
    }
 
    /* mop up an odd byte, if necessary */
    if (nleft == 1) {
        *(u_char *)(&answer) = *(u_char *)w ;
        sum += answer;
    }
 
    /* add back carry outs from top 16 bits to low 16 bits */
    sum = (sum >> 16) + (sum & 0xffff); /* add hi 16 to low 16 */
    sum += (sum >> 16);         /* add carry */
    answer = ~sum;              /* truncate to 16 bits */
    return(answer);
}




unsigned long int host2ip(char *host)
{
	struct sockaddr_in sin;
	struct hostent *hent;
      
	if ((hent=gethostbyname(host)) == NULL){
		perror("gethostbyname");
		return -1;
	}
	memcpy((char *)&sin.sin_addr,hent->h_addr, hent->h_length);
	return sin.sin_addr.s_addr;
}

char *inet_nt0a(u_long source)
{
	struct in_addr koko;

	koko.s_addr = source;
	return(inet_ntoa(koko));
}

void icmp_echo(unsigned long int dest, int id, int seq) 
{
struct sockaddr_in sin_dst;

	((struct iphdr *)packet)->daddr    = dest;
	((struct iphdr *)packet)->check    = 0;
	((struct iphdr *)packet)->check    = in_cksum(packet, IPHDRSIZE);

	((struct icmphdr *)(packet+IPHDRSIZE))->un.echo.id  = id;
	((struct icmphdr *)(packet+IPHDRSIZE))->un.echo.sequence = seq;
	((struct icmphdr *)(packet+IPHDRSIZE))->checksum = 0;
	((struct icmphdr *)(packet+IPHDRSIZE))->checksum = in_cksum(\
			packet+IPHDRSIZE,ICMPHDRSIZE);

	sin_dst.sin_addr.s_addr = dest;
	sin_dst.sin_family = AF_INET;

	if (sendto(raw_send,packet,IPHDRSIZE+ICMPHDRSIZE,0,\
		(struct sockaddr*)&sin_dst,sizeof(struct sockaddr))==-1)
		puts("sendto error");
}

void usage(char *progname)
{
	printf("%s [-hVvb] [-u ms] [-t tries] [-s sec] [-f filename] targethost\n",progname);
	printf(" -u: delay in ms between two icmp echoes (default 10000)\n");
	printf(" -b: use this if u want to scan AAA.BBB.xxx.xxx ie 256*256 hosts\n");
	printf(" -t: tries (default 1)\n");
	printf(" -s: time in sec to wait for replies after last echo send (default 10)\n");
	printf(" -f: file to save the results (default \"IP\")\n");
	printf(" -v: verbose\n");
	printf(" -V: more verbose\n");
	printf(" -h: this message\n");
}
                     
int main(int argc, char **argv)
{
struct sockaddr_in recv_dst;
unsigned long da_ip;
char buffer[4096]="IP"; //default filename
char reply[256*256];
int b=1;
int on=1,verbose=0,verbose2=0;
int i,j,n,len,timez=10,max_try=1;
FILE *log;
pid_t pid;
unsigned long int nip;
struct iphdr *ip=(struct iphdr*)buffer;
struct icmphdr *icmp=(struct icmphdr*)(buffer+IPHDRSIZE);

int o; //for getopt stuff
u_long usec=10000;
char *targethost;
char *progname = argv[0];

	 printf("3lite-subnet scanner 3.0 \n");
	 printf("ADM 0wnz U... \n");
	 printf("GreetzZ : ALL ADM & [[- HeiKe -]] & bheu ;)) \n");

	if (argc <2){usage(progname); exit(0);}
	while ((o = getopt(argc, argv, "u:f:t:s:vbVh")) != EOF)
		switch((char) o){
			case 'u':
				if (optarg)
					usec = atoi(optarg);
				break;
			case 'b':
				b=256;
				break;
			case 't':
				if (optarg)
					max_try = atoi(optarg);
				break;
			case 's':
				if (optarg)
					timez = atoi(optarg);
				break;
			case 'f':
				if (optarg)
					strcpy(buffer,optarg);
				break;
			case 'v':
				verbose2 = 1;
				break;
			case 'V':
				verbose = 1;
				verbose2 = 1;
				break;
			case 'h':
				usage(progname);
				exit(0);
		}
	if (optind >= argc) {
		usage(progname);
		exit(1);
	}
	targethost = argv[optind];

	if ((log=fopen(buffer,"w")) == NULL){
		perror("fopen");
		exit(1);
	}
	if ((raw_send=socket(AF_INET, SOCK_RAW, 255)) == -1){
		printf("cant open raw socket for sending\n");
		exit(1);
	}
	if ((raw_icmp=socket(AF_INET ,SOCK_RAW ,1)) == -1){
		printf("can't open raw socket for receiving\n");
		exit(1);
	}
	ioctl(raw_icmp,FIONBIO,&on);

	if (!(nip=host2ip(targethost))) exit(1);
 	da_ip=ntohl(nip);
	if (b==1)
		da_ip = da_ip & 0xFFFFFF00; 
	else
		da_ip=da_ip & 0xFFFF0000;

	switch (pid=fork()) {

  	    case -1:
		perror("fork");
		exit(1);

	    case 0:
		memset(reply,0,sizeof(reply));
		while (1) {
		  len=sizeof(struct sockaddr);
		  n=recvfrom(raw_icmp,buffer,sizeof(buffer),0,
		  	(struct sockaddr*)&recv_dst,&len);
               	  if ((n!=-1) && !(icmp->type)) {
			if (verbose) printf("-->reply from %s (id=%i,seq=%i)\n",
				inet_nt0a(ip->saddr),icmp->un.echo.id,
				icmp->un.echo.sequence);
			if (!reply[icmp->un.echo.sequence]) {
			  fprintf(log,"%s\n",inet_nt0a(ip->saddr));
			  fflush(log);
			  reply[icmp->un.echo.sequence]=1;
			}
		  }
		}
		break;

	    default:
		for (j=0;j<max_try;j++) 
		for (i=0;i<(256*b);i++) {
			if (verbose2) printf("send echo to: %s (id=%i, seq=%i)\n",
				inet_nt0a(htonl(da_ip+i)),j,i);
			icmp_echo(htonl(da_ip+i),j,i);
			usleep(usec);
		}
		sleep(timez);
		kill(pid,SIGTERM);
	}
	exit(0);
} 
           
