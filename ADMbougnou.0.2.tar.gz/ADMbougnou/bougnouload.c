#include <stdio.h>
#include <unistd.h>
#include <pwd.h>
       
main ()
{
char  *passwd;
char  yo[255];
char tmp[255];
memset (tmp,0,sizeof(tmp));
printf ("ADMbougnou (c) The ADM Crew\n");
printf ("simple file system encryption\n\n");
printf ("URL http://zolo.freelsd.net/~antilove/bougnou.html\n\n\n");
passwd = getpass ("password>");
strncpy (tmp,passwd,254);
passwd = getpass ("confirm your password>");
if ( strcmp (tmp,passwd) )
 {
  fprintf (stderr,"password mismatch!\n");
  exit (0);
 }

sprintf (yo,"passwd=%s\0",passwd);
execl ("/sbin/insmod","insmod","/usr/local/ADM/bougnou/ADMbougnou.o",yo,NULL);
}
       