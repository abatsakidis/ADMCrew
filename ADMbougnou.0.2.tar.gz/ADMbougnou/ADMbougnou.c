/*          *          *          *         *          *         *         *  

              .                       .                             .
          ,ooo$.                  ,ooo$.                    .   oooo$.
           ooooo.                  ooooo.                  oo.   ooooo.
         s. ooooo.     .the.     s. ooooo.    .crew.      oooo.   ooooo.
        oos. ooooo.             oos. ooooo.              oooooo.   ooooo.
    __ ooo$ _ ooooo. _________ ooo$ _ ooooo. __________ oooMoooo. _ ooooo. __
   __ oooo ___ ooooo. _______ oooo ___ ooooo. ________ oooo"ooooo. _ ooooo. __
     oooo       oooot.       oooo       oooot.        oooo   ooooo.   oooot.   
 _  oooAoooooos. ooote. ___ oooo _______ ooote. ____ oooo ___ ooooo. _ ooote. _
   oooooooooooos. ootee.   oooo           ootee.    oooo       oooos    ootee.
  oooo"            oteee. oooDoooooooooos. oteee.  oooo         oos      oteee.
 oooo~              teeee ~oooooooooooooos. teeee oooo~          $        teeee 

                                 presents
   
                                !.ADMbougnou.!
                         simple file system encryption


simple (hum hum at least one day of code :>) file encryption 
why another fuqn file encryption tools ?

-cfs is sl0000000000000000wwwwwww and i hate running this weak rpc's
-i hate patch my kernel it's never work 
-i hate recompile my kernel im too old for this

so whats about a module who will encrypt all's file into the specified dir?
simply to use ?  hmm ? want it ?
heh 
you go it !

THE USAGE IS SO SIMPLE 
for setup/compile
setupbougnou
and then
bougnou
for load the module just type bougnou :)
voila :>


TODO: 
really test this code,and then debug it :>
more error checking ( i live in a dangeurous world )
make a tool for convert the file you have encrypted with one password
to a new password

BUGS:
dunno yet
but i would not use it under a non ext2fs 
hmm and yes maybe find a way for sending the password in a better way

ETC:
mail me at antilove@el8.org for comment's bug's etc 
plz be precise and kind !

-The ADM Crew-
*      *            *         *            	*               */


#include <linux/config.h>
#include <linux/stddef.h>
#include <linux/module.h>
#include <linux/kernel.h>

#include <linux/tqueue.h>
#include <linux/proc_fs.h>
#include <linux/stat.h>
#include <linux/sched.h>
#include <linux/dirent.h>
#include <linux/fs.h>
#include <linux/if.h>
#include <linux/netdevice.h>

#include <linux/malloc.h>
#include <linux/unistd.h>
#include <linux/string.h>
#include <sys/syscall.h>
#include <linux/dcache.h>

#include <linux/dirent.h>
#include <asm/uaccess.h>
#include <linux/uio.h>
#include <linux/stat.h>
#include <linux/file.h>
#include <linux/fcntl.h>
#include <blowfish.h>

#include  "bf_cfb64.c"
#include  "bf_enc.c"
#include  "bf_skey.c"

#define NENTRY 128


unsigned char cbc_iv[8] = { 0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10 };


unsigned int dont_look_at_me_plz[NENTRY];
unsigned int fd_list[NENTRY];
unsigned char cbc_iv_tmp[NENTRY][8];
int n_tmp[NENTRY];

extern void *sys_call_table[];

extern void get_random_bytes (void *buf, int nbytes);

int (*o_write) (unsigned int, char *, size_t);
int (*o_read) (unsigned int, char *, size_t);
int (*o_open) (const char *name, int flags, int mode);
int (*o_close) (unsigned int);

BF_KEY bfkey;

int
rev_strcmp (char *s, char *s1)
{
  int i;
  int n;
  char *buf;
  n = strlen (s);
  buf = kmalloc (n + 1, GFP_KERNEL);
  memset (buf, 0, n + 1);
  i = 0;
  while (n--)
    buf[i++] = s[n];
  i = strncmp (buf, s1, strlen (s1));
  kfree (buf);
  return (i);
}


int
ourpidwewant (unsigned int p, unsigned int fd)
{
  int i;
  for (i = 0; i < sizeof (dont_look_at_me_plz) / sizeof (int); i++)
    if (dont_look_at_me_plz[i] == p && fd_list[i] == fd)
      return (i);

  return (-1);
}

void
delthepid (unsigned int p, unsigned int fd)
{
  int i;
  for (i = 0; i < sizeof (dont_look_at_me_plz) / sizeof (int); i++)
    if (dont_look_at_me_plz[i] == p && fd_list[i] == fd)
      {
	dont_look_at_me_plz[i] = 0;
	fd_list[i] = -1;
      }
}

int
addthepid (int p, int fd)
{
  int i;
  for (i = 0; i < sizeof (dont_look_at_me_plz) / sizeof (int); i++)
    if (dont_look_at_me_plz[i] == 0)
      {
	dont_look_at_me_plz[i] = p;
	fd_list[i] = fd;
	return (i);
      }
return (-1);
}



void
BF_Init (char *password)
{
  BF_set_key (&bfkey, strlen (password), (unsigned char *) password);
}


int
n_close (unsigned int fd)
{
  int r;
  if ((r = ourpidwewant (current->pid, fd)) != -1)
    {
      delthepid (current->pid, fd);
    }

  return (o_close (fd));
}


void 
write8 (unsigned int fd, int id)
{

  unsigned char blah[8];
  unsigned char bloh[8];
  mm_segment_t old_fs;

  get_random_bytes (&blah, 8);

  old_fs = get_fs ();
  set_fs (get_ds ());

  BF_cfb64_encrypt (
		    (unsigned char *) blah,
		    (unsigned char *) bloh,
		    (long) 8,
		    &bfkey,
		    (unsigned char *) &cbc_iv_tmp[id],
		    &n_tmp[id], BF_ENCRYPT);

  o_write (fd, bloh, 8);
  set_fs (old_fs);
}

void 
read8 (unsigned int fd, int id)
{
  mm_segment_t old_fs;

  unsigned char blah[8];
  unsigned char bloh[8];

  old_fs = get_fs ();
  set_fs (get_ds ());


  o_read (fd, blah, 8);

  BF_cfb64_encrypt ((unsigned char *) blah,
		    (unsigned char *) bloh,
		    (long) 8,
		    &bfkey,
		    (unsigned char *) &cbc_iv_tmp[id],
		    &n_tmp[id], BF_DECRYPT);

  set_fs (old_fs);

}

int
n_open (const char *name, int flags, int mode)
{
  struct file *file;
  struct dentry *dentry;
  int r;
  int x = 0;
  char *buffer;

  r = o_open (name, flags, mode);

  if (r > 2)			/* ignore stdin out etc */
    {
      buffer = kmalloc (1024, GFP_KERNEL);
      memset (buffer, 0, 1024);

      file = fget (r);
      dentry = file->f_dentry->d_parent;

      while (dentry->d_name.name[0] != '/')
	{
	  strcat (buffer, dentry->d_name.name);
	  strcat (buffer, "/");
	  dentry = dentry->d_parent;
	}

      if (rev_strcmp (buffer, CPATH) == 0)
	{
	  x = addthepid (current->pid, r);

	  memcpy (cbc_iv_tmp[x], cbc_iv, 8);
	  n_tmp[x] = 0;

	  if (flags & O_CREAT)
	    {
	      write8 (r, x);
	    }
	  else
	    read8 (r, x);
	}

      kfree (buffer);
      fput (file);
    }
  return (r);
}

int
n_write (unsigned int fd, char *buf, size_t count)
{
  int r;
  int ret;
  unsigned char *bfout;
  unsigned char iv[8];
  mm_segment_t old_fs;

  if ((r = ourpidwewant (current->pid, fd)) != -1)
    {

      /* encryptedez */
      bfout = kmalloc (count, GFP_KERNEL);
      memset (bfout, 0, count);

      memcpy (iv, cbc_iv, 8);

      old_fs = get_fs ();
      set_fs (get_ds ());






      BF_cfb64_encrypt (
			(unsigned char *) buf,
			(unsigned char *) bfout,
			(long) count,
			&bfkey,
			(unsigned char *) &cbc_iv_tmp[r],
			&n_tmp[r], BF_ENCRYPT);


      ret = o_write (fd, bfout, count);
      set_fs (old_fs);

      kfree (bfout);
      return (ret);
    }
  return (o_write (fd, buf, count));
}

int
n_read (unsigned int fd, char *buf, size_t count)
{
  unsigned int r;
  unsigned int ret;
  unsigned char *bfout;
  unsigned char iv[8];
  mm_segment_t old_fs;



  if ((r = ourpidwewant (current->pid, fd)) != -1)
    {
      /* encryptedez */
      bfout = kmalloc (count, GFP_USER);
      memset (bfout, 0, count);

      old_fs = get_fs ();
      set_fs (get_ds ());

      ret = o_read (fd, bfout, count);



      memcpy (iv, cbc_iv, 8);



      BF_cfb64_encrypt ((unsigned char *) bfout, (unsigned char *) buf,
			(long) count,
			&bfkey,
			(unsigned char *) &cbc_iv_tmp[r],
			&n_tmp[r], BF_DECRYPT);

      set_fs (old_fs);


      kfree (bfout);


      return (ret);
    }

  ret = o_read (fd, buf, count);
  return (ret);
}

static char *passwd = NULL;
MODULE_PARM (passwd, "s");

int
init_module (void)
{
  printk ("<1> ADMbougnou 0.1 ALPHA (c) The ADM Crew Loaded!\n");
  printk ("<1> comments,bugs,etc mail me at antilove@el8.org\n");


  if (passwd == NULL)
    {
      printk ("<1> ADMbougnou:NO PASSWORD SET ?!?!\n");
      return (0);
    }
  BF_Init (passwd);

  o_write = sys_call_table[SYS_write];
  sys_call_table[SYS_write] = (void *) n_write;

  o_read = sys_call_table[SYS_read];
  sys_call_table[SYS_read] = (void *) n_read;

  o_open = sys_call_table[SYS_open];
  sys_call_table[SYS_open] = (void *) n_open;

  o_close = sys_call_table[SYS_close];
  sys_call_table[SYS_close] = (void *) n_close;


  return (0);
}


void
cleanup_module (void)
{
  printk ("<1> ADMbougnou killed..you bastard!\n");
  sys_call_table[SYS_write] = o_write;
  sys_call_table[SYS_read] = o_read;
  sys_call_table[SYS_open] = o_open;
  sys_call_table[SYS_close] = o_close;
}
