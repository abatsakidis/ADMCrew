#include <stdio.h>
#include <stdlib.h>
#include <string.h>
       
char * rev (char * c)
{
char * buf;
int i;
int n;
buf = calloc (1, strlen (c) + 1);
i = strlen (c);
n = 0;
while (i--) 
       buf [n++] = c [i];     
return (buf);
}

main (int argc, char **argv)
{
char *tmp;
char *c;
int i=0;
char pp[2048];
c = strdup (argv[1]);
tmp = strtok (c,"/");
if (tmp == NULL)
 {
  printf ("what this path?\n");
  exit (0);
 }
memset (pp,0,sizeof(pp));
strcat (pp,"/");
strcat (pp,rev (tmp));
while ( (tmp = strtok (NULL,"/")))
  {
  strcat (pp,"/");
  strcat (pp,rev (tmp));  
  }
printf ("%s\n",pp);
}